### SC Compression

Version 0.2.6
-

### Tools:
- Decompression
- Compression

TestPyPi - https://test.pypi.org/project/sc-compression/ <br>
PyPi - https://pypi.org/project/sc-compression/
